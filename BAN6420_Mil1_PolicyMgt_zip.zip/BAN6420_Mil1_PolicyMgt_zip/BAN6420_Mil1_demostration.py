# Demostration of functionality
from Policyholder import Policyholder
from Product import Product
from Payment import Payment

class Product:
    def __init__(self, product_id, name, premium):
        self.product_id = product_id
        self.name = name
        self.premium = premium

    def get_details(self):
        return {
            'product_id': self.product_id,
            'name': self.name,
            'premium': self.premium
        }

class Policyholder:
    def __init__(self, policyholder_id, name, email, active=True):
        self.policyholder_id = policyholder_id
        self.name = name
        self.email = email
        self.active = active  # Initialize the active attribute
        self.products = []  # Initialize an empty list to hold products
        self.payments = []  # Initialize an empty list to hold payments

    def add_product(self, product):
        self.products.append(product)  # Add the product to the list

    def add_payment(self, payment):
        self.payments.append(payment)  # Add the payment to the list

    def get_details(self):
        return {
            'policyholder_id': self.policyholder_id,
            'name': self.name,
            'email': self.email,
            'active': self.active,
            'products': [product.get_details() for product in self.products],
            'payments': [payment.get_details() for payment in self.payments]
        }

class Payment:
    def __init__(self, payment_id, amount, date, policyholder):
        self.payment_id = payment_id
        self.amount = amount
        self.date = date
        self.policyholder = policyholder  # Store the associated policyholder

    def process(self):
        # Payment processing logic here
        print(f"Processed payment of {self.amount} for {self.policyholder.name} on {self.date}")

    def get_details(self):
        return {
            'payment_id': self.payment_id,
            'amount': self.amount,
            'date': self.date
        }

# Example usage
product1 = Product(product_id=1, name='Health Insurance', premium=800)
product2 = Product(product_id=2, name='Car Insurance', premium=500)

policyholder1 = Policyholder(policyholder_id=1, name='Andrew Smith', email='andrew@insuranceabc.com', active=True)
policyholder2 = Policyholder(policyholder_id=2, name='Kola Adejumo', email='kola@insuranceabc.com', active=False)

# Add products to policyholders
policyholder1.add_product(product1)
policyholder2.add_product(product2)

# Create and process payments
payment1 = Payment(payment_id=1, amount=800, date='2024-08-03', policyholder=policyholder1)
payment1.process()
policyholder1.add_payment(payment1)

payment2 = Payment(payment_id=2, amount=500, date='2024-08-04', policyholder=policyholder2)
payment2.process()
policyholder2.add_payment(payment2)

# Print payment details for verification
print(policyholder1.payments)
print(policyholder2.payments)
print(policyholder1.get_details())
print(policyholder2.get_details())

Output:
Processed payment of 800 for Andrew Smith on 2024-08-03
Processed payment of 500 for Kola Adejumo on 2024-08-04
[<__main__.Payment object at 0x000002027CE19CA0>]
[<__main__.Payment object at 0x000002027CE17EC0>]
{'policyholder_id': 1, 'name': 'Andrew Smith', 'email': 'andrew@insuranceabc.com', 'active': True, 'products': [{'product_id': 1, 'name': 'Health Insurance', 'premium': 800}], 'payments': [{'payment_id': 1, 'amount': 800, 'date': '2024-08-03'}]}
{'policyholder_id': 2, 'name': 'Kola Adejumo', 'email': 'kola@insuranceabc.com', 'active': False, 'products': [{'product_id': 2, 'name': 'Car Insurance', 'premium': 500}], 'payments': [{'payment_id': 2, 'amount': 500, 'date': '2024-08-04'}]}