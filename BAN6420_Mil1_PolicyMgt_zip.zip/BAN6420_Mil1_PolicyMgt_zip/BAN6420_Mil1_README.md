# Policy Management System

# Overview
This project gives an insurance company the ability to manage policymakers, products, and payments through the implementation of a basic policy management system

## Files Included
- `BAN6420_Mil1_policyholder.py`: Class for managing policyholders.
- `BAN6420_Mil1_product.py`: Class for managing insurance products.
- `BAN6420_Mil1_payment.py`: Class for handling payment processing.
- `BAN6420_Mil1_demostration.py`: Demonstrates the functionality of the classes.
- `BAN6420_Mil1_README.md`: Instructions for running the project

## Requirements
- Python 3.x

### Instructions
-  Ensure you have Python 3.x installed

### Run the Program
1. Navigate to the project directory
2. Run the `BAN6420_Mil1_demostration.py` file to see the demonstrations of the functionality of the system.
```bash
     python BAN6420_Mil1_demostration.py
     ```
### Functionality
- Two policyholders are created by the program, who then register them, add products, handle payments and show their account details.

### Output result
The result will show policyholder registration, product additions, payment processing, and account details for each policyholder.



