# Policyholders Class
class Policyholder:
    def __init__(self, policyholder_id, name, email):
        self.policyholder_id = policyholder_id
        self.name = name
        self.email = email
        self.active = True
        self.products = []
        self.payments = []

    def register_product(self, product):
        self.products.append(product)
	 	
    def suspend(self):
        self.active = False

    def reactivate(self):
        self.active = True

    def add_payment(self, payment):
        self.payments.append(payment)
	
    def get_details(self):
        return {
            'policyholder_id': self.policyholder_id,
            'name': self.name,
            'email': self.email,
            'active': self.active,
            'products': [product.get_details() for product in self.products],
            'payments': [payment.get_details() for payment in self.payments]
        }
