# Product Class
class Product:
    def __init__(self, product_id, name, price):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.active = True

    def update(self, name=None, price=None):
        if name:
            self.name = name
        if price:
            self.price = price

    def suspend(self):
        self.active = False

    def get_details(self):
        return {
            'product_id': self.product_id,
            'name': self.name,
            'price': self.price,
            'active': self.active
        }
