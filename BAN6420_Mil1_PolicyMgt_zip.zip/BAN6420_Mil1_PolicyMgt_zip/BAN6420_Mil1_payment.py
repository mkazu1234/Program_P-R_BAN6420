# Payment Class
class Payment:
    def __init__(self, payment_id, policyholder, amount, date):
        self.policyholder = policyholder
        self.payment_id = payment_id
        self.amount = amount
        self.date = date
        self.payment_processed = False
	
    def process_payment(self):
        self.payment_processed = True

    def send_reminder(self):
    	if not self.payment_processed:
	     print(f"Reminder: Payment due for {self.policyholder.name} for product {self.product.name}.")
    
    def apply_penalty(self):
    	if not self.payment_processed:
	     print(f"Penalty applied to {self.policyholder.name} for non payment of product {self.product.name}.")

    def get_details(self):
        return {
            'payment_id': self.payment_id,
	        'policyholder': self.policyholder,
            'amount': self.amount,
            'date': self.date,
            'payment_processed': self.payment_processed
        }
