# Employee Salary Data Analysis

## Oveview

As part of this project, salary information for employees in San Francisco is being analyzed. The tasks included in this analysis are data import, function creation to get employee details, dictionary processing, error handling, exporting employee details to a CSV file, and R display of the data.

## Files

- `BAN6420_Mod2_Salary_Function.ipynb`: Jupyter Notebook containing the Python code.
- `BAN6420_Mod2_ Salary_Function_RScrriptDisplay_Data.R`: R script to unzip the folder and display data.
- `Employee_Profile.zip`: Zipped folder containing the employee details CSV file.
- `BAN6420_Mod2_Salary_Funcion_README.md`: This file.

## Usage

### Python

1. Ensure you have Python and Jupyter Notebook installed on your system.
2. Open and run the `BAN6420_Mod2_Salary_Function.ipynb` notebook to generate employee details and export them to a CSV file.

### R

1. Ensure you have R installed on your system.
2. Run the `BAN6420_Mod2_ Salary_Function_RScrriptDisplay_Data.R` script to unzip the folder and display the data.

## Error Handling

Error handling is built into the Python code to handle possible problems with employee detail retrieval.
