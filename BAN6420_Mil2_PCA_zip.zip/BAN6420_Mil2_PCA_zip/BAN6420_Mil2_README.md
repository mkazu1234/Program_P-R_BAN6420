# PCA and logistic regression of the breast cancer dataset

This project shows how to use the Breast Cancer dataset from sklearn for Principal Component Analysis (PCA) and optionally use Logistic Regression for classification.

## Requirements
- Python 3.x
- NumPy
- Pandas
- Matplotlib
- scikit-learn

To install the required packages using pip: (cmd)

```bash

pip install numpy pandas scikit-learn matplotlib

How to Run the code
- Unzip the project folder
- Navigate to the project directory
- Run the Python script

'''bash

python BAN6420_Mil2_PCA.py

The script will output:
- A visualization of the PCA results (saved as 'pca_visualization.png')
- (Optional) Accuracy and classification report for the logistic regression model


To view the README file
- Navigate to the project directory
- Open the "BAN6420_Mil2_README.md" file to view

Both BAN6420_Mil2_PCA.py and BAN6420_Mil2_README.md files are zipped with folder name "BAN6420_Mil2_PCA_zip" folder and uploaded to the GitHub repository and shared through the link

https://github.com/mkazu1234/Program_P-R_BAN6420



