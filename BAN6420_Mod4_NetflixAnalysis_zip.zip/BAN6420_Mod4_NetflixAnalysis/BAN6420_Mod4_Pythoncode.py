import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import zipfile
import os

# Data Preparation
# unzip the dataset
with zipfile.ZipFile('Downloads/netflix_data.zip', 'r') as zip_ref:
    zip_ref.extractall()

# Load the dataset 
df = pd.read_csv('Downloads/netflix_data.csv', low_memory=False)
df.to_csv('Netflix_shows_movies_v2.csv', index=False)

# Data Cleaning: Address missing values
# Handle missing values 
print(df.dtypes) # Identify nnn-numeric columns
numeric_cols = df.select_dtypes(include=['int64', 'float64']).columns
df[numeric_cols] = df[numeric_cols].astype('float64')

# Filling the missing values with the mean
df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].mean())

# Verify the mssing values are filled correctly
print(df.isnull().sum())

# Statistical analysis using correlaton matric
numeric_df = df.select_dtypes(include=['number']) # Numeric columns selection
correlation_matrix = numeric_df.corr()
df_encoded = pd.get_dummies(df, drop_first=True)
correlation_matrix = df_encoded.corr()  # Correlation calculation

# Visualize the correlation matrix
plt.figure(figsize=(12, 10)) 
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm')
plt.title('Correlation Matrix')
plt.show()

# Data Exploration
print(df.describe())
print(df.info())
print(df.head())
print(df.columns)

# Data Visualization
# Create a new column 'genre'
df['genre'] = df['listed_in'].str.split(',').str[0]

# Data Visualization
# Most watched genres
plt.figure(figsize=(10, 6))
sns.countplot(y='genre', data=df, order=df['genre'].value_counts().index)
plt.title('Most Watched Genres')
plt.xlabel('Count')

# Ratings distribution
plt.figure(figsize=(10, 6))
sns.histplot(df['rating'], bins=10, kde=True)
plt.title('Ratings Distribution')
plt.xlabel('Rating')
plt.ylabel('Frequency')
plt.show()

# Export a sample dataset for R integration
df.to_csv('Netflix_shows_movies_sample_v2.csv', index=False)

# Create a zip file for submission
import zipfile

# Create a zip file for submission
with zipfile.ZipFile('BAN6420_Mod4_NetflixAnalysis.zip', 'w') as zipf:
    zipf.write('Netflix_shows_movies_v2.csv')
    zipf.write('Netflix_shows_movies_sample_v2.csv')
