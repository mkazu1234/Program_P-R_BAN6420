# Load necessary libraries for Integration
library(ggplot2)

# Load the dataset
df <- read.csv('Netflix_shows_movies_sample_v2.csv')

# Create a ratings distribution plot in R
ggplot(df, aes(x=rating)) +
  geom_bar(fill="blue", color="black", alpha=0.7) +
  labs(title="Ratings Distribution") +
  theme(axis.text.x = element_text(angle=45, hjust=1))