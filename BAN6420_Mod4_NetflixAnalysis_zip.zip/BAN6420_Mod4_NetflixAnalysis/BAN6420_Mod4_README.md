## Instructions

### Requirements
- Python 3.x
- R and RStudio
- Required Python libraries: pandas, seaborn, matplotlib
- Required R libraries: ggplot2

### Python Code
1. Unzip the dataset and rename it to "Netflix_shows_movies_v2.csv".
2. Run `BAN6420_Mil1_Pythoncode.py` to perform data cleaning, exploration, and visualization.
 - Ensure you have the required libraries installed: pandas, seaborn, matplotlib.

### R Code
1. Ensure the "Netflix_shows_movies_v2.csv" file is in the "BAN6420_Mod4_NetflixAnalysis" directory.
2. Run `BAN6420_Mod4_IntegrationRcode.R` to generate the ratings distribution plot in R.
   - Ensure you have the required library installed: ggplot2.


### Data Cleaning
- Uses the filled mean values to address missing values.

### Data Exploration
- Used for dataset description and statistical analysis.

### Data Visualization
- Visualized the most watched genres and ratings distribution using Python libraries.
- Implemented the ratings distribution plot in R.

## Files
- `Netflix_shows_movies_v2.csv`: Dataset
- `Netflix_shows_movies_sample_v2.csv`: R integration Sample dataset
- `BAN6420_Mod4_Pythoncode.py`: Python script for data preparation, cleaning, exploration, and visualization.
- `BAN6420_Mod4_IntegrationRcode.R`: R script for generating the ratings distribution plot, chart and visualization.
- `BAN6420_Mod4_README.md`: Instructions and details about the project.
- `BAN6420_Mod4_NetflixAnalysis.zip`: Zipped file containing all necessary files for submission.
- GitHub Repository: A copy of the `BAN6420_Mod4_NewtflixAnalysis.zip` is also saved at the GitHub repository for accessibility and review.
