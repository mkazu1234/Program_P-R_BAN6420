# Fashion MNIST CNN Classification In Python/R

This project uses the Fashion MNIST dataset to categorize images using an implementation of a Convolutional Neural Network (CNN) using Keras.

## Requirements

- Python 3.x
- R 4.0+
- RStudio
- TensorFlow 2.16.2
- Keras package 2.15.0
- NumPy
- Matplotlib

Install the required Python packages if not available with: (cmd)
```bash
pip install tensorflow numpy matplotlib

Install the required R packages in Rstudio:
'''r
install.packages("keras")
library(keras)
library(tensorflow)
install_keras()
install_tensorflow()

How to Run the Python Script
- Unzip the project folder
- Navigate to the project directory
- Run the Python script
'''bash
python BAN6420_MOD6_FashionMNIST_CNN.py

How to Run the R Script
- Unzip the project folder
- Navigate to the project directory
- Run the R  script in R Studio or command line
'''bash
Rscript BAN6420_MOD6_FashionMNIST_CNN.R

To view the README file
- Navigate to the project directory
- Open the "BAN6420_MOD6_FashionMNIST_CNN_README.md" file to view

Both BAN6420_MOD6_FashionMNIST_CNN.py, BAN6420_MOD6_FashionMNIST_CNN.R, and BAN6420_MOD6_FashionMNIST_CNN_README.md files are zipped with the folder name "BAN6420_MOD6_FashionMNIST_CNN_zip" folder and uploaded to the GitHub repository and shared through the link

https://github.com/mkazu1234/Program_P-R_BAN6420



