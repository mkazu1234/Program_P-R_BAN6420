# Install necessary packages if not already installed
# install.packages("keras")
# install.packages("tensorflow")

install.packages("keras")
install.packages("tensorflow")
install_tensorflow
install_keras()
library(keras)
library(tensorflow)

# Load the Fashion MNIST dataset
fashion_mnist <- dataset_fashion_mnist()
x_train <- fashion_mnist$train$x
y_train <- fashion_mnist$train$y
x_test <- fashion_mnist$test$x
y_test <- fashion_mnist$test$y

# Check the shapes of the datasets
cat("Training data shape:", dim(x_train), "\n")  # (60000, 28, 28)
cat("Training labels shape:", length(y_train), "\n")  # (60000,)
cat("Test data shape:", dim(x_test), "\n")  # (10000, 28, 28)
cat("Test labels shape:", length(y_test), "\n")  # (10000,)

# Normalize the data
x_train <- x_train / 255
x_test <- x_test / 255

# Preprocess (Reshape) the data to add the channel dimension
x_train <- array_reshape(x_train, c(dim(x_train)[1], 28, 28, 1))
x_test <- array_reshape(x_test, c(dim(x_test)[1], 28, 28, 1))

# Convert Labels to one-hot encoding
y_train_categorical <- to_categorical(y_train, num_classes = 10)
y_test_categorical <- to_categorical(y_test, num_classes = 10)

# Define the CNN model
model <- keras_model_sequential() %>% # Create a sequential model
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = 'relu', input_shape = c(28, 28, 1)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu') %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu') %>%
  layer_flatten() %>%
  layer_dense(units = 64, activation = 'relu') %>%
  layer_dense(units = 10, activation = 'softmax')

# Compile the model
model %>% compile(
  optimizer = 'adam',
  loss = 'categorical_crossentropy',
  metrics = 'accuracy'
)

# Train the model
model %>% fit(
  x_train, y_train,
  epochs = 5, batch_size = 64,
  validation_split = 0.2
)

# Evaluate the model
score <- model %>% evaluate(x_test, y_test)
cat('Test accuracy:', score$acc, "\n")

# Make predictions on the test data
predictions <- model %>% predict_classes(x_test)

# Function to plot the image and prediction
plot_image <- function(index, predictions, true_labels, images) {
  true_label <- true_labels[index]
  img <- images[index,,,]
  
  plot(as.raster(img), main = paste("True:", true_label, "Pred:", predictions[index]), col = gray.colors(256))
}

# Class names for Fashion MNIST
class_names <- c('T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat', 
                 'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot')

# Plot two test images and their predictions
par(mfrow = c(1, 2))
plot_image(1, class_names[predictions + 1], class_names[apply(y_test, 1, which.max)], x_test)
plot_image(2, class_names[predictions + 1], class_names[apply(y_test, 1, which.max)], x_test)


