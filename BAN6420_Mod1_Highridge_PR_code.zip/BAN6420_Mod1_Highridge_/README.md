# Highridge Construction Company Workers Payment System

The Highridge Construction Company's worker payment system implementations in Python and R can be seen in this repository.

## Instructions:
1. Make sure Python 3. x and R are installed.
2. Save both Python and R code in separate files (e.g., 'p_code.py' and 'r_code.r').
3. Run the Python code using 'python p_code.py' in your terminal/command prompt.
4. Run the R code using 'Rscript r_code.r' in your terminal/command prompt.
5. With conditional statements applied, the programs will produce payment slips for 400 workers.