
R version 4.4.0 (2024-04-24 ucrt) -- "Puppy Cup"
Copyright (C) 2024 The R Foundation for Statistical Computing
Platform: x86_64-w64-mingw32/x64

R is free software and comes with ABSOLUTELY NO WARRANTY.
You are welcome to redistribute it under certain conditions.
Type 'license()' or 'licence()' for distribution details.

  Natural language support but running in an English locale

R is a collaborative project with many contributors.
Type 'contributors()' for more information and
'citation()' on how to cite R or R packages in publications.

Type 'demo()' for some demos, 'help()' for on-line help, or
'help.start()' for an HTML browser interface to help.
Type 'q()' to quit R.

> # Dynamically create a list of 400 workers
> set.seed(123)
> workers <- data.frame(
+   name = paste("Worker", 1:400),
+   salary = round(runif(400, 7500, 30000), 2),
+   gender = sample(c("male", "female"), 400, replace = TRUE)
+ )
> 
> # Generate payment slips with conditional statements
> for (i in 1:nrow(workers)) {
+   tryCatch(
+     expr = {
+       cat("Payment Slip for", workers$name[i], "\n")
+       cat("Salary: $", workers$salary[i], "\n")
+       
+       if (workers$salary[i] > 10000 && workers$salary[i] < 20000) {
+         cat("Employee Level: A1\n")
+       } else if (workers$salary[i] > 7500 && workers$salary[i] < 30000 && workers$gender[i] == "female") {
+         cat("Employee Level: A5-F\n")
+       } else {
+         cat("Employee Level: Unassigned\n")
+       }
+       
+       cat("\n")  # empty line for readability
+     },
+     error = function(e) {
+       cat("Error:", e$message, "\n")
+     }
+   )
+ }
Payment Slip for Worker 1 
Salary: $ 13970.49 
Employee Level: A1

Payment Slip for Worker 2 
Salary: $ 25236.87 
Employee Level: Unassigned

Payment Slip for Worker 3 
Salary: $ 16701.98 
Employee Level: A1

Payment Slip for Worker 4 
Salary: $ 27367.89 
Employee Level: Unassigned

Payment Slip for Worker 5 
Salary: $ 28660.51 
Employee Level: Unassigned

Payment Slip for Worker 6 
Salary: $ 8525.02 
Employee Level: Unassigned

Payment Slip for Worker 7 
Salary: $ 19382.37 
Employee Level: A1

Payment Slip for Worker 8 
Salary: $ 27579.43 
Employee Level: Unassigned

Payment Slip for Worker 9 
Salary: $ 19907.29 
Employee Level: A1

Payment Slip for Worker 10 
Salary: $ 17773.83 
Employee Level: A1

Payment Slip for Worker 11 
Salary: $ 29028.75 
Employee Level: A5-F

Payment Slip for Worker 12 
Salary: $ 17700.02 
Employee Level: A1

Payment Slip for Worker 13 
Salary: $ 22745.34 
Employee Level: A5-F

Payment Slip for Worker 14 
Salary: $ 20384.25 
Employee Level: A5-F

Payment Slip for Worker 15 
Salary: $ 9815.81 
Employee Level: A5-F

Payment Slip for Worker 16 
Salary: $ 27746.06 
Employee Level: Unassigned

Payment Slip for Worker 17 
Salary: $ 13036.97 
Employee Level: A1

Payment Slip for Worker 18 
Salary: $ 8446.34 
Employee Level: Unassigned

Payment Slip for Worker 19 
Salary: $ 14878.22 
Employee Level: A1

Payment Slip for Worker 20 
Salary: $ 28976.33 
Employee Level: Unassigned

Payment Slip for Worker 21 
Salary: $ 27514.63 
Employee Level: Unassigned

Payment Slip for Worker 22 
Salary: $ 23088.08 
Employee Level: Unassigned

Payment Slip for Worker 23 
Salary: $ 21911.4 
Employee Level: Unassigned

Payment Slip for Worker 24 
Salary: $ 29871.07 
Employee Level: Unassigned

Payment Slip for Worker 25 
Salary: $ 22253.38 
Employee Level: Unassigned

Payment Slip for Worker 26 
Salary: $ 23441.94 
Employee Level: Unassigned

Payment Slip for Worker 27 
Salary: $ 19741.49 
Employee Level: A1

Payment Slip for Worker 28 
Salary: $ 20868.2 
Employee Level: A5-F

Payment Slip for Worker 29 
Salary: $ 14006.09 
Employee Level: A1

Payment Slip for Worker 30 
Salary: $ 10810.06 
Employee Level: A1

Payment Slip for Worker 31 
Salary: $ 29168.05 
Employee Level: Unassigned

Payment Slip for Worker 32 
Salary: $ 27801.73 
Employee Level: A5-F

Payment Slip for Worker 33 
Salary: $ 23040.87 
Employee Level: A5-F

Payment Slip for Worker 34 
Salary: $ 25398.02 
Employee Level: Unassigned

Payment Slip for Worker 35 
Salary: $ 8053.81 
Employee Level: A5-F

Payment Slip for Worker 36 
Salary: $ 18250.41 
Employee Level: A1

Payment Slip for Worker 37 
Salary: $ 24565.34 
Employee Level: A5-F

Payment Slip for Worker 38 
Salary: $ 12369.18 
Employee Level: A1

Payment Slip for Worker 39 
Salary: $ 14659.07 
Employee Level: A1

Payment Slip for Worker 40 
Salary: $ 12711.58 
Employee Level: A1

Payment Slip for Worker 41 
Salary: $ 10713 
Employee Level: A1

Payment Slip for Worker 42 
Salary: $ 16827.29 
Employee Level: A1

Payment Slip for Worker 43 
Salary: $ 16808.8 
Employee Level: A1

Payment Slip for Worker 44 
Salary: $ 15799.02 
Employee Level: A1

Payment Slip for Worker 45 
Salary: $ 10930.01 
Employee Level: A1

Payment Slip for Worker 46 
Salary: $ 10623.14 
Employee Level: A1

Payment Slip for Worker 47 
Salary: $ 12743.27 
Employee Level: A1

Payment Slip for Worker 48 
Salary: $ 17984.16 
Employee Level: A1

Payment Slip for Worker 49 
Salary: $ 13484.38 
Employee Level: A1

Payment Slip for Worker 50 
Salary: $ 26801.12 
Employee Level: A5-F

Payment Slip for Worker 51 
Salary: $ 8531.2 
Employee Level: A5-F

Payment Slip for Worker 52 
Salary: $ 17449.5 
Employee Level: A1

Payment Slip for Worker 53 
Salary: $ 25475.81 
Employee Level: A5-F

Payment Slip for Worker 54 
Salary: $ 10242.73 
Employee Level: A1

Payment Slip for Worker 55 
Salary: $ 20121.33 
Employee Level: A5-F

Payment Slip for Worker 56 
Salary: $ 12146.96 
Employee Level: A1

Payment Slip for Worker 57 
Salary: $ 10369.46 
Employee Level: A1

Payment Slip for Worker 58 
Salary: $ 24449.43 
Employee Level: A5-F

Payment Slip for Worker 59 
Salary: $ 27638.52 
Employee Level: Unassigned

Payment Slip for Worker 60 
Salary: $ 15925.41 
Employee Level: A1

Payment Slip for Worker 61 
Salary: $ 22465.09 
Employee Level: A5-F

Payment Slip for Worker 62 
Salary: $ 9633.91 
Employee Level: Unassigned

Payment Slip for Worker 63 
Salary: $ 16139.32 
Employee Level: A1

Payment Slip for Worker 64 
Salary: $ 13673.63 
Employee Level: A1

Payment Slip for Worker 65 
Salary: $ 25829.4 
Employee Level: Unassigned

Payment Slip for Worker 66 
Salary: $ 17591.62 
Employee Level: A1

Payment Slip for Worker 67 
Salary: $ 25726.45 
Employee Level: A5-F

Payment Slip for Worker 68 
Salary: $ 25778.76 
Employee Level: Unassigned

Payment Slip for Worker 69 
Salary: $ 25372.7 
Employee Level: A5-F

Payment Slip for Worker 70 
Salary: $ 17396.21 
Employee Level: A1

Payment Slip for Worker 71 
Salary: $ 24475.69 
Employee Level: Unassigned

Payment Slip for Worker 72 
Salary: $ 21657.48 
Employee Level: Unassigned

Payment Slip for Worker 73 
Salary: $ 23479.1 
Employee Level: A5-F

Payment Slip for Worker 74 
Salary: $ 7514.06 
Employee Level: A5-F

Payment Slip for Worker 75 
Salary: $ 18194.62 
Employee Level: A1

Payment Slip for Worker 76 
Salary: $ 12452.67 
Employee Level: A1

Payment Slip for Worker 77 
Salary: $ 16045.87 
Employee Level: A1

Payment Slip for Worker 78 
Salary: $ 21287.35 
Employee Level: Unassigned

Payment Slip for Worker 79 
Salary: $ 15415.45 
Employee Level: A1

Payment Slip for Worker 80 
Salary: $ 10000.55 
Employee Level: A1

Payment Slip for Worker 81 
Salary: $ 12981.44 
Employee Level: A1

Payment Slip for Worker 82 
Salary: $ 22531.25 
Employee Level: A5-F

Payment Slip for Worker 83 
Salary: $ 16897.05 
Employee Level: A1

Payment Slip for Worker 84 
Salary: $ 25234.41 
Employee Level: A5-F

Payment Slip for Worker 85 
Salary: $ 9814.45 
Employee Level: Unassigned

Payment Slip for Worker 86 
Salary: $ 17285.09 
Employee Level: A1

Payment Slip for Worker 87 
Salary: $ 29661.53 
Employee Level: A5-F

Payment Slip for Worker 88 
Salary: $ 27593.65 
Employee Level: Unassigned

Payment Slip for Worker 89 
Salary: $ 27445.55 
Employee Level: A5-F

Payment Slip for Worker 90 
Salary: $ 11438.68 
Employee Level: A1

Payment Slip for Worker 91 
Salary: $ 10440.65 
Employee Level: A1

Payment Slip for Worker 92 
Salary: $ 22194.79 
Employee Level: A5-F

Payment Slip for Worker 93 
Salary: $ 15229.12 
Employee Level: A1

Payment Slip for Worker 94 
Salary: $ 22277.06 
Employee Level: A5-F

Payment Slip for Worker 95 
Salary: $ 14708.4 
Employee Level: A1

Payment Slip for Worker 96 
Salary: $ 11723.05 
Employee Level: A1

Payment Slip for Worker 97 
Salary: $ 25101.62 
Employee Level: A5-F

Payment Slip for Worker 98 
Salary: $ 9605.89 
Employee Level: Unassigned

Payment Slip for Worker 99 
Salary: $ 18002.53 
Employee Level: A1

Payment Slip for Worker 100 
Salary: $ 19008.87 
Employee Level: A1

Payment Slip for Worker 101 
Salary: $ 20999.75 
Employee Level: A5-F

Payment Slip for Worker 102 
Salary: $ 14988.53 
Employee Level: A1

Payment Slip for Worker 103 
Salary: $ 18493.79 
Employee Level: A1

Payment Slip for Worker 104 
Salary: $ 28975.66 
Employee Level: A5-F

Payment Slip for Worker 105 
Salary: $ 18365.3 
Employee Level: A1

Payment Slip for Worker 106 
Salary: $ 27532.88 
Employee Level: Unassigned

Payment Slip for Worker 107 
Salary: $ 28074.86 
Employee Level: Unassigned

Payment Slip for Worker 108 
Salary: $ 21196.54 
Employee Level: Unassigned

Payment Slip for Worker 109 
Salary: $ 16740.52 
Employee Level: A1

Payment Slip for Worker 110 
Salary: $ 10809.63 
Employee Level: A1

Payment Slip for Worker 111 
Salary: $ 28544.25 
Employee Level: A5-F

Payment Slip for Worker 112 
Salary: $ 14277.65 
Employee Level: A1

Payment Slip for Worker 113 
Salary: $ 8866.21 
Employee Level: A5-F

Payment Slip for Worker 114 
Salary: $ 28823.86 
Employee Level: Unassigned

Payment Slip for Worker 115 
Salary: $ 23713.42 
Employee Level: A5-F

Payment Slip for Worker 116 
Salary: $ 10701.62 
Employee Level: A1

Payment Slip for Worker 117 
Salary: $ 19858.9 
Employee Level: A1

Payment Slip for Worker 118 
Salary: $ 28967.05 
Employee Level: Unassigned

Payment Slip for Worker 119 
Salary: $ 20673.38 
Employee Level: A5-F

Payment Slip for Worker 120 
Salary: $ 16601.48 
Employee Level: A1

Payment Slip for Worker 121 
Salary: $ 22077.6 
Employee Level: A5-F

Payment Slip for Worker 122 
Salary: $ 14695.96 
Employee Level: A1

Payment Slip for Worker 123 
Salary: $ 14423.7 
Employee Level: A1

Payment Slip for Worker 124 
Salary: $ 12444.77 
Employee Level: A1

Payment Slip for Worker 125 
Salary: $ 15813.5 
Employee Level: A1

Payment Slip for Worker 126 
Salary: $ 29644.93 
Employee Level: A5-F

Payment Slip for Worker 127 
Salary: $ 10969.55 
Employee Level: A1

Payment Slip for Worker 128 
Salary: $ 9548.49 
Employee Level: Unassigned

Payment Slip for Worker 129 
Salary: $ 10692.91 
Employee Level: A1

Payment Slip for Worker 130 
Salary: $ 23025.16 
Employee Level: Unassigned

Payment Slip for Worker 131 
Salary: $ 21433.27 
Employee Level: A5-F

Payment Slip for Worker 132 
Salary: $ 27556.37 
Employee Level: A5-F

Payment Slip for Worker 133 
Salary: $ 22642.48 
Employee Level: A5-F

Payment Slip for Worker 134 
Salary: $ 24084.25 
Employee Level: Unassigned

Payment Slip for Worker 135 
Salary: $ 19225.55 
Employee Level: A1

Payment Slip for Worker 136 
Salary: $ 22346.37 
Employee Level: A5-F

Payment Slip for Worker 137 
Salary: $ 25990.62 
Employee Level: A5-F

Payment Slip for Worker 138 
Salary: $ 25191.33 
Employee Level: A5-F

Payment Slip for Worker 139 
Salary: $ 29545.99 
Employee Level: A5-F

Payment Slip for Worker 140 
Salary: $ 17387.21 
Employee Level: A1

Payment Slip for Worker 141 
Salary: $ 14513.3 
Employee Level: A1

Payment Slip for Worker 142 
Salary: $ 16713.19 
Employee Level: A1

Payment Slip for Worker 143 
Salary: $ 7735.51 
Employee Level: A5-F

Payment Slip for Worker 144 
Salary: $ 11636.61 
Employee Level: A1

Payment Slip for Worker 145 
Salary: $ 26461.41 
Employee Level: A5-F

Payment Slip for Worker 146 
Salary: $ 12701.14 
Employee Level: A1

Payment Slip for Worker 147 
Salary: $ 12879.75 
Employee Level: A1

Payment Slip for Worker 148 
Salary: $ 9225.55 
Employee Level: A5-F

Payment Slip for Worker 149 
Salary: $ 13028.78 
Employee Level: A1

Payment Slip for Worker 150 
Salary: $ 23973.04 
Employee Level: Unassigned

Payment Slip for Worker 151 
Salary: $ 26567.7 
Employee Level: A5-F

Payment Slip for Worker 152 
Salary: $ 18694.36 
Employee Level: A1

Payment Slip for Worker 153 
Salary: $ 16227.95 
Employee Level: A1

Payment Slip for Worker 154 
Salary: $ 13045.1 
Employee Level: A1

Payment Slip for Worker 155 
Salary: $ 9999.67 
Employee Level: A5-F

Payment Slip for Worker 156 
Salary: $ 16274.87 
Employee Level: A1

Payment Slip for Worker 157 
Salary: $ 20368.54 
Employee Level: A5-F

Payment Slip for Worker 158 
Salary: $ 12380.09 
Employee Level: A1

Payment Slip for Worker 159 
Salary: $ 17507.28 
Employee Level: A1

Payment Slip for Worker 160 
Salary: $ 12404.79 
Employee Level: A1

Payment Slip for Worker 161 
Salary: $ 18801.74 
Employee Level: A1

Payment Slip for Worker 162 
Salary: $ 15462.85 
Employee Level: A1

Payment Slip for Worker 163 
Salary: $ 22124.67 
Employee Level: A5-F

Payment Slip for Worker 164 
Salary: $ 15931.06 
Employee Level: A1

Payment Slip for Worker 165 
Salary: $ 15497.52 
Employee Level: A1

Payment Slip for Worker 166 
Salary: $ 19507.98 
Employee Level: A1

Payment Slip for Worker 167 
Salary: $ 24157.52 
Employee Level: A5-F

Payment Slip for Worker 168 
Salary: $ 12474.82 
Employee Level: A1

Payment Slip for Worker 169 
Salary: $ 16786.79 
Employee Level: A1

Payment Slip for Worker 170 
Salary: $ 13477.95 
Employee Level: A1

Payment Slip for Worker 171 
Salary: $ 21674.39 
Employee Level: A5-F

Payment Slip for Worker 172 
Salary: $ 11636.14 
Employee Level: A1

Payment Slip for Worker 173 
Salary: $ 26931.99 
Employee Level: A5-F

Payment Slip for Worker 174 
Salary: $ 24297.78 
Employee Level: Unassigned

Payment Slip for Worker 175 
Salary: $ 22536.4 
Employee Level: Unassigned

Payment Slip for Worker 176 
Salary: $ 21405.4 
Employee Level: A5-F

Payment Slip for Worker 177 
Salary: $ 15875.36 
Employee Level: A1

Payment Slip for Worker 178 
Salary: $ 19421.3 
Employee Level: A1

Payment Slip for Worker 179 
Salary: $ 27180.35 
Employee Level: A5-F

Payment Slip for Worker 180 
Salary: $ 20589.38 
Employee Level: Unassigned

Payment Slip for Worker 181 
Salary: $ 26394.77 
Employee Level: Unassigned

Payment Slip for Worker 182 
Salary: $ 14530.08 
Employee Level: A1

Payment Slip for Worker 183 
Salary: $ 23436.53 
Employee Level: Unassigned

Payment Slip for Worker 184 
Salary: $ 13462.9 
Employee Level: A1

Payment Slip for Worker 185 
Salary: $ 20872.72 
Employee Level: A5-F

Payment Slip for Worker 186 
Salary: $ 18329.02 
Employee Level: A1

Payment Slip for Worker 187 
Salary: $ 13463.24 
Employee Level: A1

Payment Slip for Worker 188 
Salary: $ 20203.28 
Employee Level: A5-F

Payment Slip for Worker 189 
Salary: $ 28046.74 
Employee Level: A5-F

Payment Slip for Worker 190 
Salary: $ 27792.17 
Employee Level: Unassigned

Payment Slip for Worker 191 
Salary: $ 13668.75 
Employee Level: A1

Payment Slip for Worker 192 
Salary: $ 14733.36 
Employee Level: A1

Payment Slip for Worker 193 
Salary: $ 29676.92 
Employee Level: Unassigned

Payment Slip for Worker 194 
Salary: $ 21449.85 
Employee Level: A5-F

Payment Slip for Worker 195 
Salary: $ 28589.57 
Employee Level: Unassigned

Payment Slip for Worker 196 
Salary: $ 17996.99 
Employee Level: A1

Payment Slip for Worker 197 
Salary: $ 16653.73 
Employee Level: A1

Payment Slip for Worker 198 
Salary: $ 22332.68 
Employee Level: Unassigned

Payment Slip for Worker 199 
Salary: $ 10927.8 
Employee Level: A1

Payment Slip for Worker 200 
Salary: $ 20389.51 
Employee Level: A5-F

Payment Slip for Worker 201 
Salary: $ 12871.34 
Employee Level: A1

Payment Slip for Worker 202 
Salary: $ 29153.08 
Employee Level: A5-F

Payment Slip for Worker 203 
Salary: $ 21030.73 
Employee Level: A5-F

Payment Slip for Worker 204 
Salary: $ 19088.17 
Employee Level: A1

Payment Slip for Worker 205 
Salary: $ 16557.9 
Employee Level: A1

Payment Slip for Worker 206 
Salary: $ 27305.55 
Employee Level: Unassigned

Payment Slip for Worker 207 
Salary: $ 15692.07 
Employee Level: A1

Payment Slip for Worker 208 
Salary: $ 13985.38 
Employee Level: A1

Payment Slip for Worker 209 
Salary: $ 11339.52 
Employee Level: A1

Payment Slip for Worker 210 
Salary: $ 11373.86 
Employee Level: A1

Payment Slip for Worker 211 
Salary: $ 18345.96 
Employee Level: A1

Payment Slip for Worker 212 
Salary: $ 13191.71 
Employee Level: A1

Payment Slip for Worker 213 
Salary: $ 12365.73 
Employee Level: A1

Payment Slip for Worker 214 
Salary: $ 22673.47 
Employee Level: Unassigned

Payment Slip for Worker 215 
Salary: $ 8572.43 
Employee Level: A5-F

Payment Slip for Worker 216 
Salary: $ 23269.19 
Employee Level: A5-F

Payment Slip for Worker 217 
Salary: $ 15417.49 
Employee Level: A1

Payment Slip for Worker 218 
Salary: $ 16701.24 
Employee Level: A1

Payment Slip for Worker 219 
Salary: $ 25971.4 
Employee Level: A5-F

Payment Slip for Worker 220 
Salary: $ 28174.29 
Employee Level: A5-F

Payment Slip for Worker 221 
Salary: $ 13856.89 
Employee Level: A1

Payment Slip for Worker 222 
Salary: $ 29124.86 
Employee Level: A5-F

Payment Slip for Worker 223 
Salary: $ 23888.87 
Employee Level: A5-F

Payment Slip for Worker 224 
Salary: $ 22943.44 
Employee Level: A5-F

Payment Slip for Worker 225 
Salary: $ 8688.99 
Employee Level: A5-F

Payment Slip for Worker 226 
Salary: $ 16392.45 
Employee Level: A1

Payment Slip for Worker 227 
Salary: $ 18251.52 
Employee Level: A1

Payment Slip for Worker 228 
Salary: $ 20105.7 
Employee Level: Unassigned

Payment Slip for Worker 229 
Salary: $ 23210.89 
Employee Level: Unassigned

Payment Slip for Worker 230 
Salary: $ 28102.88 
Employee Level: Unassigned

Payment Slip for Worker 231 
Salary: $ 21412.9 
Employee Level: Unassigned

Payment Slip for Worker 232 
Salary: $ 17139.48 
Employee Level: A1

Payment Slip for Worker 233 
Salary: $ 19696.81 
Employee Level: A1

Payment Slip for Worker 234 
Salary: $ 8815.77 
Employee Level: A5-F

Payment Slip for Worker 235 
Salary: $ 13369.28 
Employee Level: A1

Payment Slip for Worker 236 
Salary: $ 16435.92 
Employee Level: A1

Payment Slip for Worker 237 
Salary: $ 11949.26 
Employee Level: A1

Payment Slip for Worker 238 
Salary: $ 26218.37 
Employee Level: A5-F

Payment Slip for Worker 239 
Salary: $ 10939.96 
Employee Level: A1

Payment Slip for Worker 240 
Salary: $ 25576.92 
Employee Level: A5-F

Payment Slip for Worker 241 
Salary: $ 19803.59 
Employee Level: A1

Payment Slip for Worker 242 
Salary: $ 22402.15 
Employee Level: A5-F

Payment Slip for Worker 243 
Salary: $ 11363.22 
Employee Level: A1

Payment Slip for Worker 244 
Salary: $ 21743.75 
Employee Level: A5-F

Payment Slip for Worker 245 
Salary: $ 14517.07 
Employee Level: A1

Payment Slip for Worker 246 
Salary: $ 23802.47 
Employee Level: Unassigned

Payment Slip for Worker 247 
Salary: $ 16476.15 
Employee Level: A1

Payment Slip for Worker 248 
Salary: $ 29310.52 
Employee Level: A5-F

Payment Slip for Worker 249 
Salary: $ 29266.46 
Employee Level: Unassigned

Payment Slip for Worker 250 
Salary: $ 23850.81 
Employee Level: A5-F

Payment Slip for Worker 251 
Salary: $ 13287.38 
Employee Level: A1

Payment Slip for Worker 252 
Salary: $ 12490.23 
Employee Level: A1

Payment Slip for Worker 253 
Salary: $ 20843.53 
Employee Level: Unassigned

Payment Slip for Worker 254 
Salary: $ 13519.23 
Employee Level: A1

Payment Slip for Worker 255 
Salary: $ 19449.08 
Employee Level: A1

Payment Slip for Worker 256 
Salary: $ 25169.06 
Employee Level: A5-F

Payment Slip for Worker 257 
Salary: $ 11281.37 
Employee Level: A1

Payment Slip for Worker 258 
Salary: $ 16598.98 
Employee Level: A1

Payment Slip for Worker 259 
Salary: $ 18110.47 
Employee Level: A1

Payment Slip for Worker 260 
Salary: $ 27032.4 
Employee Level: A5-F

Payment Slip for Worker 261 
Salary: $ 28328.43 
Employee Level: Unassigned

Payment Slip for Worker 262 
Salary: $ 27344.5 
Employee Level: Unassigned

Payment Slip for Worker 263 
Salary: $ 22669.2 
Employee Level: A5-F

Payment Slip for Worker 264 
Salary: $ 28878.76 
Employee Level: Unassigned

Payment Slip for Worker 265 
Salary: $ 19120.01 
Employee Level: A1

Payment Slip for Worker 266 
Salary: $ 20471.68 
Employee Level: Unassigned

Payment Slip for Worker 267 
Salary: $ 15067.45 
Employee Level: A1

Payment Slip for Worker 268 
Salary: $ 15314.8 
Employee Level: A1

Payment Slip for Worker 269 
Salary: $ 7950.55 
Employee Level: A5-F

Payment Slip for Worker 270 
Salary: $ 18813.29 
Employee Level: A1

Payment Slip for Worker 271 
Salary: $ 27098.48 
Employee Level: A5-F

Payment Slip for Worker 272 
Salary: $ 7641.77 
Employee Level: Unassigned

Payment Slip for Worker 273 
Salary: $ 9121.29 
Employee Level: Unassigned

Payment Slip for Worker 274 
Salary: $ 11194.75 
Employee Level: A1

Payment Slip for Worker 275 
Salary: $ 24832.52 
Employee Level: A5-F

Payment Slip for Worker 276 
Salary: $ 24041.65 
Employee Level: A5-F

Payment Slip for Worker 277 
Salary: $ 29367.2 
Employee Level: A5-F

Payment Slip for Worker 278 
Salary: $ 17995.63 
Employee Level: A1

Payment Slip for Worker 279 
Salary: $ 9173.65 
Employee Level: Unassigned

Payment Slip for Worker 280 
Salary: $ 22098.41 
Employee Level: A5-F

Payment Slip for Worker 281 
Salary: $ 24568.35 
Employee Level: Unassigned

Payment Slip for Worker 282 
Salary: $ 10584.89 
Employee Level: A1

Payment Slip for Worker 283 
Salary: $ 16423.15 
Employee Level: A1

Payment Slip for Worker 284 
Salary: $ 12562.17 
Employee Level: A1

Payment Slip for Worker 285 
Salary: $ 8804.07 
Employee Level: Unassigned

Payment Slip for Worker 286 
Salary: $ 16407.59 
Employee Level: A1

Payment Slip for Worker 287 
Salary: $ 8960.89 
Employee Level: A5-F

Payment Slip for Worker 288 
Salary: $ 12582.44 
Employee Level: A1

Payment Slip for Worker 289 
Salary: $ 8729.15 
Employee Level: A5-F

Payment Slip for Worker 290 
Salary: $ 22581.35 
Employee Level: Unassigned

Payment Slip for Worker 291 
Salary: $ 14199.19 
Employee Level: A1

Payment Slip for Worker 292 
Salary: $ 9766.24 
Employee Level: Unassigned

Payment Slip for Worker 293 
Salary: $ 9117.84 
Employee Level: Unassigned

Payment Slip for Worker 294 
Salary: $ 27309.91 
Employee Level: A5-F

Payment Slip for Worker 295 
Salary: $ 24470.57 
Employee Level: A5-F

Payment Slip for Worker 296 
Salary: $ 25873.63 
Employee Level: A5-F

Payment Slip for Worker 297 
Salary: $ 29598.16 
Employee Level: A5-F

Payment Slip for Worker 298 
Salary: $ 9830.99 
Employee Level: A5-F

Payment Slip for Worker 299 
Salary: $ 9728.44 
Employee Level: A5-F

Payment Slip for Worker 300 
Salary: $ 25473.71 
Employee Level: A5-F

Payment Slip for Worker 301 
Salary: $ 25152.94 
Employee Level: A5-F

Payment Slip for Worker 302 
Salary: $ 7712.17 
Employee Level: Unassigned

Payment Slip for Worker 303 
Salary: $ 25028.98 
Employee Level: Unassigned

Payment Slip for Worker 304 
Salary: $ 23911.29 
Employee Level: Unassigned

Payment Slip for Worker 305 
Salary: $ 21677.97 
Employee Level: A5-F

Payment Slip for Worker 306 
Salary: $ 18320.49 
Employee Level: A1

Payment Slip for Worker 307 
Salary: $ 11024.33 
Employee Level: A1

Payment Slip for Worker 308 
Salary: $ 7684.85 
Employee Level: Unassigned

Payment Slip for Worker 309 
Salary: $ 17680.31 
Employee Level: A1

Payment Slip for Worker 310 
Salary: $ 18576.6 
Employee Level: A1

Payment Slip for Worker 311 
Salary: $ 16265.71 
Employee Level: A1

Payment Slip for Worker 312 
Salary: $ 17954.98 
Employee Level: A1

Payment Slip for Worker 313 
Salary: $ 23548.78 
Employee Level: Unassigned

Payment Slip for Worker 314 
Salary: $ 8744.29 
Employee Level: A5-F

Payment Slip for Worker 315 
Salary: $ 15482.62 
Employee Level: A1

Payment Slip for Worker 316 
Salary: $ 25563.28 
Employee Level: A5-F

Payment Slip for Worker 317 
Salary: $ 26303.45 
Employee Level: A5-F

Payment Slip for Worker 318 
Salary: $ 12849.36 
Employee Level: A1

Payment Slip for Worker 319 
Salary: $ 15464.69 
Employee Level: A1

Payment Slip for Worker 320 
Salary: $ 26779.92 
Employee Level: Unassigned

Payment Slip for Worker 321 
Salary: $ 26709.68 
Employee Level: A5-F

Payment Slip for Worker 322 
Salary: $ 14157.65 
Employee Level: A1

Payment Slip for Worker 323 
Salary: $ 10808.59 
Employee Level: A1

Payment Slip for Worker 324 
Salary: $ 23339.82 
Employee Level: A5-F

Payment Slip for Worker 325 
Salary: $ 9835.65 
Employee Level: A5-F

Payment Slip for Worker 326 
Salary: $ 8258.87 
Employee Level: Unassigned

Payment Slip for Worker 327 
Salary: $ 29986.6 
Employee Level: Unassigned

Payment Slip for Worker 328 
Salary: $ 8284.68 
Employee Level: A5-F

Payment Slip for Worker 329 
Salary: $ 15113.8 
Employee Level: A1

Payment Slip for Worker 330 
Salary: $ 28088.93 
Employee Level: A5-F

Payment Slip for Worker 331 
Salary: $ 21387.79 
Employee Level: Unassigned

Payment Slip for Worker 332 
Salary: $ 13941.42 
Employee Level: A1

Payment Slip for Worker 333 
Salary: $ 24100.44 
Employee Level: Unassigned

Payment Slip for Worker 334 
Salary: $ 26266.22 
Employee Level: Unassigned

Payment Slip for Worker 335 
Salary: $ 14571.09 
Employee Level: A1

Payment Slip for Worker 336 
Salary: $ 18582.75 
Employee Level: A1

Payment Slip for Worker 337 
Salary: $ 23190.91 
Employee Level: A5-F

Payment Slip for Worker 338 
Salary: $ 21932.9 
Employee Level: Unassigned

Payment Slip for Worker 339 
Salary: $ 21988.27 
Employee Level: A5-F

Payment Slip for Worker 340 
Salary: $ 29501.7 
Employee Level: Unassigned

Payment Slip for Worker 341 
Salary: $ 16831.55 
Employee Level: A1

Payment Slip for Worker 342 
Salary: $ 10186.61 
Employee Level: A1

Payment Slip for Worker 343 
Salary: $ 19335.67 
Employee Level: A1

Payment Slip for Worker 344 
Salary: $ 12564.15 
Employee Level: A1

Payment Slip for Worker 345 
Salary: $ 18444.26 
Employee Level: A1

Payment Slip for Worker 346 
Salary: $ 15829.83 
Employee Level: A1

Payment Slip for Worker 347 
Salary: $ 29625.38 
Employee Level: Unassigned

Payment Slip for Worker 348 
Salary: $ 16237.18 
Employee Level: A1

Payment Slip for Worker 349 
Salary: $ 12658.01 
Employee Level: A1

Payment Slip for Worker 350 
Salary: $ 21524.19 
Employee Level: A5-F

Payment Slip for Worker 351 
Salary: $ 10572.15 
Employee Level: A1

Payment Slip for Worker 352 
Salary: $ 29268.06 
Employee Level: A5-F

Payment Slip for Worker 353 
Salary: $ 19089.12 
Employee Level: A1

Payment Slip for Worker 354 
Salary: $ 11169.08 
Employee Level: A1

Payment Slip for Worker 355 
Salary: $ 21492.8 
Employee Level: Unassigned

Payment Slip for Worker 356 
Salary: $ 29683.97 
Employee Level: A5-F

Payment Slip for Worker 357 
Salary: $ 22547.36 
Employee Level: A5-F

Payment Slip for Worker 358 
Salary: $ 16925.61 
Employee Level: A1

Payment Slip for Worker 359 
Salary: $ 14775.26 
Employee Level: A1

Payment Slip for Worker 360 
Salary: $ 26293.24 
Employee Level: Unassigned

Payment Slip for Worker 361 
Salary: $ 10735.88 
Employee Level: A1

Payment Slip for Worker 362 
Salary: $ 11838.36 
Employee Level: A1

Payment Slip for Worker 363 
Salary: $ 27676.62 
Employee Level: A5-F

Payment Slip for Worker 364 
Salary: $ 14432.69 
Employee Level: A1

Payment Slip for Worker 365 
Salary: $ 15674.26 
Employee Level: A1

Payment Slip for Worker 366 
Salary: $ 25138.8 
Employee Level: A5-F

Payment Slip for Worker 367 
Salary: $ 11851.02 
Employee Level: A1

Payment Slip for Worker 368 
Salary: $ 7899.73 
Employee Level: A5-F

Payment Slip for Worker 369 
Salary: $ 16648.68 
Employee Level: A1

Payment Slip for Worker 370 
Salary: $ 18371.27 
Employee Level: A1

Payment Slip for Worker 371 
Salary: $ 16991.51 
Employee Level: A1

Payment Slip for Worker 372 
Salary: $ 15213.2 
Employee Level: A1

Payment Slip for Worker 373 
Salary: $ 26995.87 
Employee Level: A5-F

Payment Slip for Worker 374 
Salary: $ 17739.93 
Employee Level: A1

Payment Slip for Worker 375 
Salary: $ 19509.71 
Employee Level: A1

Payment Slip for Worker 376 
Salary: $ 29186.47 
Employee Level: A5-F

Payment Slip for Worker 377 
Salary: $ 24928.31 
Employee Level: Unassigned

Payment Slip for Worker 378 
Salary: $ 12199.72 
Employee Level: A1

Payment Slip for Worker 379 
Salary: $ 14447.7 
Employee Level: A1

Payment Slip for Worker 380 
Salary: $ 29355.21 
Employee Level: A5-F

Payment Slip for Worker 381 
Salary: $ 20660.25 
Employee Level: Unassigned

Payment Slip for Worker 382 
Salary: $ 24618.53 
Employee Level: Unassigned

Payment Slip for Worker 383 
Salary: $ 15885.96 
Employee Level: A1

Payment Slip for Worker 384 
Salary: $ 24806.86 
Employee Level: Unassigned

Payment Slip for Worker 385 
Salary: $ 19597.74 
Employee Level: A1

Payment Slip for Worker 386 
Salary: $ 28064.9 
Employee Level: Unassigned

Payment Slip for Worker 387 
Salary: $ 11669.17 
Employee Level: A1

Payment Slip for Worker 388 
Salary: $ 13849.91 
Employee Level: A1

Payment Slip for Worker 389 
Salary: $ 9636.65 
Employee Level: A5-F

Payment Slip for Worker 390 
Salary: $ 12235.96 
Employee Level: A1

Payment Slip for Worker 391 
Salary: $ 29484.73 
Employee Level: Unassigned

Payment Slip for Worker 392 
Salary: $ 14166.8 
Employee Level: A1

Payment Slip for Worker 393 
Salary: $ 23834.62 
Employee Level: Unassigned

Payment Slip for Worker 394 
Salary: $ 25177.98 
Employee Level: A5-F

Payment Slip for Worker 395 
Salary: $ 9871.9 
Employee Level: Unassigned

Payment Slip for Worker 396 
Salary: $ 12890.88 
Employee Level: A1

Payment Slip for Worker 397 
Salary: $ 13587.26 
Employee Level: A1

Payment Slip for Worker 398 
Salary: $ 9773.82 
Employee Level: A5-F

Payment Slip for Worker 399 
Salary: $ 10153.06 
Employee Level: A1

Payment Slip for Worker 400 
Salary: $ 29802.82 
Employee Level: A5-F


> > save.image("C:\\Users\\Admin\\Downloads\\BAN6420_Module1_Highridge_python_code\\r_code.r")
> 
