Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
import random
# To dynamically create a list of 400 workers
workers = []
for i in range(400):
    worker = {
        "name": f"Worker {i + 1}",
        "salary": round(random.uniform(7500, 30000), 2),
        "gender": random.choice(["male", "female"])
    }
    workers.append(worker)

    
for i in range(400):
    worker = {
        "name": f"Worker {i + 1}",
        "salary": round(random.uniform(7500, 30000), 2),
        "gender": random.choice(["male", "female"])
    }
    workers.append(worker)
# To generate payment slips with conditional statements
try:
    
SyntaxError: invalid syntax
    try:
        
SyntaxError: unexpected indent
for worker in workers:
    try:
        print(f"Payment Slip for {worker['name']}")
        print(f"Salary: ${worker['salary']}")
        # To determine employee level based on salary and gender
        if 10000 < worker['salary'] < 20000:
            print("Employee Level: A1")
        elif 7500 < worker['salary'] < 30000 and worker['gender'] == "female":
            print("Employee Level: A5-F")
         else:
...              
SyntaxError: unindent does not match any outer indentation level
>>> for worker in workers:
...     try:
...         print(f"Payment Slip for {worker['name']}")
...         print(f"Salary: ${worker['salary']}")
...         # To determine employee level based on salary and gender
...         if 10000 < worker['salary'] < 20000:
...             print("Employee Level: A1")
...         elif 7500 < worker['salary'] < 30000 and worker['gender'] == "female":
...             print("Employee Level: A5-F")
...     else:
...         
SyntaxError: expected 'except' or 'finally' block
>>> 
>>> for worker in workers:
...     try:
...         print(f"Payment Slip for {worker['name']}")
...         print(f"Salary: ${worker['salary']}")
...         # To determine employee level based on salary and gender
...         if 10000 < worker['salary'] < 20000:
...             print("Employee Level: A1")
...         elif 7500 < worker['salary'] < 30000 and worker['gender'] == "female":
...             print("Employee Level: A5-F")
...         else:
...             print("Employee Level: Unassigned")
...         print()  # Empty line for readability
...     except Exception as e:
...         print(f"Error: {e}")
... 
...         
Payment Slip for Worker 1
Salary: $28332.96
Employee Level: A5-F

Payment Slip for Worker 2
Salary: $7631.42
Employee Level: Unassigned

Payment Slip for Worker 3
Salary: $13164.15
Employee Level: A1

Payment Slip for Worker 4
Salary: $26813.67
Employee Level: A5-F

Payment Slip for Worker 5
Salary: $26196.11
Employee Level: Unassigned

Payment Slip for Worker 6
Salary: $12673.63
Employee Level: A1

Payment Slip for Worker 7
Salary: $28459.81
Employee Level: Unassigned

Payment Slip for Worker 8
Salary: $11646.65
Employee Level: A1

Payment Slip for Worker 9
Salary: $18972.84
Employee Level: A1

Payment Slip for Worker 10
Salary: $23191.03
Employee Level: Unassigned

Payment Slip for Worker 11
Salary: $10678.39
Employee Level: A1

Payment Slip for Worker 12
Salary: $29538.42
Employee Level: A5-F

Payment Slip for Worker 13
Salary: $16854.15
Employee Level: A1

Payment Slip for Worker 14
Salary: $11550.43
Employee Level: A1

Payment Slip for Worker 15
Salary: $28275.3
Employee Level: Unassigned

Payment Slip for Worker 16
Salary: $18553.06
Employee Level: A1

Payment Slip for Worker 17
Salary: $16121.57
Employee Level: A1

Payment Slip for Worker 18
Salary: $22330.27
Employee Level: A5-F

Payment Slip for Worker 19
Salary: $12883.22
Employee Level: A1

Payment Slip for Worker 20
Salary: $15212.26
Employee Level: A1

Payment Slip for Worker 21
Salary: $21292.22
Employee Level: A5-F

Payment Slip for Worker 22
Salary: $16431.39
Employee Level: A1

Payment Slip for Worker 23
Salary: $16761.52
Employee Level: A1

Payment Slip for Worker 24
Salary: $22013.38
Employee Level: Unassigned

Payment Slip for Worker 25
Salary: $24379.81
Employee Level: A5-F

Payment Slip for Worker 26
Salary: $15009.08
Employee Level: A1

Payment Slip for Worker 27
Salary: $15671.74
Employee Level: A1

Payment Slip for Worker 28
Salary: $27294.09
Employee Level: A5-F

Payment Slip for Worker 29
Salary: $29273.27
Employee Level: Unassigned

Payment Slip for Worker 30
Salary: $20075.73
Employee Level: A5-F

Payment Slip for Worker 31
Salary: $9569.73
Employee Level: Unassigned

Payment Slip for Worker 32
Salary: $9728.83
Employee Level: A5-F

Payment Slip for Worker 33
Salary: $7851.79
Employee Level: A5-F

Payment Slip for Worker 34
Salary: $18685.91
Employee Level: A1

Payment Slip for Worker 35
Salary: $22426.03
Employee Level: A5-F

Payment Slip for Worker 36
Salary: $13757.8
Employee Level: A1

Payment Slip for Worker 37
Salary: $21720.5
Employee Level: Unassigned

Payment Slip for Worker 38
Salary: $16834.8
Employee Level: A1

Payment Slip for Worker 39
Salary: $19089.97
Employee Level: A1

Payment Slip for Worker 40
Salary: $9011.77
Employee Level: A5-F

Payment Slip for Worker 41
Salary: $15843.43
Employee Level: A1

Payment Slip for Worker 42
Salary: $13056.04
Employee Level: A1

Payment Slip for Worker 43
Salary: $17930.13
Employee Level: A1

Payment Slip for Worker 44
Salary: $18793.35
Employee Level: A1

Payment Slip for Worker 45
Salary: $21576.52
Employee Level: Unassigned

Payment Slip for Worker 46
Salary: $18664.56
Employee Level: A1

Payment Slip for Worker 47
Salary: $25570.01
Employee Level: A5-F

Payment Slip for Worker 48
Salary: $10236.57
Employee Level: A1

Payment Slip for Worker 49
Salary: $9185.85
Employee Level: A5-F

Payment Slip for Worker 50
Salary: $25093.15
Employee Level: A5-F

Payment Slip for Worker 51
Salary: $18026.02
Employee Level: A1

Payment Slip for Worker 52
Salary: $20265.69
Employee Level: Unassigned

Payment Slip for Worker 53
Salary: $15506.73
Employee Level: A1

Payment Slip for Worker 54
Salary: $9871.59
Employee Level: A5-F

Payment Slip for Worker 55
Salary: $21643.48
Employee Level: Unassigned

Payment Slip for Worker 56
Salary: $23013.63
Employee Level: A5-F

Payment Slip for Worker 57
Salary: $25798.66
Employee Level: Unassigned

Payment Slip for Worker 58
Salary: $21599.85
Employee Level: A5-F

Payment Slip for Worker 59
Salary: $11151.39
Employee Level: A1

Payment Slip for Worker 60
Salary: $7636.56
Employee Level: A5-F

Payment Slip for Worker 61
Salary: $19998.05
Employee Level: A1

Payment Slip for Worker 62
Salary: $16393.16
Employee Level: A1

Payment Slip for Worker 63
Salary: $13998.85
Employee Level: A1

Payment Slip for Worker 64
Salary: $19472.91
Employee Level: A1

Payment Slip for Worker 65
Salary: $12276.67
Employee Level: A1

Payment Slip for Worker 66
Salary: $16806.24
Employee Level: A1

Payment Slip for Worker 67
Salary: $20924.06
Employee Level: A5-F

Payment Slip for Worker 68
Salary: $11481.75
Employee Level: A1

Payment Slip for Worker 69
Salary: $12994.69
Employee Level: A1

Payment Slip for Worker 70
Salary: $21656.44
Employee Level: Unassigned

Payment Slip for Worker 71
Salary: $8744.08
Employee Level: A5-F

Payment Slip for Worker 72
Salary: $11498.13
Employee Level: A1

Payment Slip for Worker 73
Salary: $8435.29
Employee Level: Unassigned

Payment Slip for Worker 74
Salary: $9454.91
Employee Level: A5-F

Payment Slip for Worker 75
Salary: $14587.18
Employee Level: A1

Payment Slip for Worker 76
Salary: $10685.25
Employee Level: A1

Payment Slip for Worker 77
Salary: $12599.5
Employee Level: A1

Payment Slip for Worker 78
Salary: $24090.43
Employee Level: Unassigned

Payment Slip for Worker 79
Salary: $20243.77
Employee Level: Unassigned

Payment Slip for Worker 80
Salary: $9040.98
Employee Level: A5-F

Payment Slip for Worker 81
Salary: $22705.74
Employee Level: A5-F

Payment Slip for Worker 82
Salary: $28222.33
Employee Level: A5-F

Payment Slip for Worker 83
Salary: $27411.92
Employee Level: Unassigned

Payment Slip for Worker 84
Salary: $20536.85
Employee Level: Unassigned

Payment Slip for Worker 85
Salary: $25136.57
Employee Level: Unassigned

Payment Slip for Worker 86
Salary: $26191.39
Employee Level: A5-F

Payment Slip for Worker 87
Salary: $12879.52
Employee Level: A1

Payment Slip for Worker 88
Salary: $25277.52
Employee Level: A5-F

Payment Slip for Worker 89
Salary: $14432.78
Employee Level: A1

Payment Slip for Worker 90
Salary: $28347.65
Employee Level: Unassigned

Payment Slip for Worker 91
Salary: $28511.49
Employee Level: A5-F

Payment Slip for Worker 92
Salary: $26351.54
Employee Level: A5-F

Payment Slip for Worker 93
Salary: $15637.44
Employee Level: A1

Payment Slip for Worker 94
Salary: $14347.81
Employee Level: A1

Payment Slip for Worker 95
Salary: $17356.94
Employee Level: A1

Payment Slip for Worker 96
Salary: $25331.06
Employee Level: Unassigned

Payment Slip for Worker 97
Salary: $21064.86
Employee Level: Unassigned

Payment Slip for Worker 98
Salary: $19292.24
Employee Level: A1

Payment Slip for Worker 99
Salary: $9362.89
Employee Level: Unassigned

Payment Slip for Worker 100
Salary: $8807.08
Employee Level: A5-F

Payment Slip for Worker 101
Salary: $20925.96
Employee Level: A5-F

Payment Slip for Worker 102
Salary: $26507.24
Employee Level: A5-F

Payment Slip for Worker 103
Salary: $17474.36
Employee Level: A1

Payment Slip for Worker 104
Salary: $23357.11
Employee Level: Unassigned

Payment Slip for Worker 105
Salary: $13048.5
Employee Level: A1

Payment Slip for Worker 106
Salary: $18443.38
Employee Level: A1

Payment Slip for Worker 107
Salary: $29401.98
Employee Level: Unassigned

Payment Slip for Worker 108
Salary: $21743.68
Employee Level: A5-F

Payment Slip for Worker 109
Salary: $20604.75
Employee Level: A5-F

Payment Slip for Worker 110
Salary: $11229.3
Employee Level: A1

Payment Slip for Worker 111
Salary: $27151.56
Employee Level: A5-F

Payment Slip for Worker 112
Salary: $11213.43
Employee Level: A1

Payment Slip for Worker 113
Salary: $26378.37
Employee Level: Unassigned

Payment Slip for Worker 114
Salary: $15457.66
Employee Level: A1

Payment Slip for Worker 115
Salary: $21810.99
Employee Level: Unassigned

Payment Slip for Worker 116
Salary: $21629.9
Employee Level: Unassigned

Payment Slip for Worker 117
Salary: $27909.16
Employee Level: Unassigned

Payment Slip for Worker 118
Salary: $20497.19
Employee Level: A5-F

Payment Slip for Worker 119
Salary: $26355.08
Employee Level: A5-F

Payment Slip for Worker 120
Salary: $16682.15
Employee Level: A1

Payment Slip for Worker 121
Salary: $21394.43
Employee Level: A5-F

Payment Slip for Worker 122
Salary: $28056.22
Employee Level: A5-F

Payment Slip for Worker 123
Salary: $27105.75
Employee Level: Unassigned

Payment Slip for Worker 124
Salary: $20975.56
Employee Level: A5-F

Payment Slip for Worker 125
Salary: $15350.73
Employee Level: A1

Payment Slip for Worker 126
Salary: $10306.46
Employee Level: A1

Payment Slip for Worker 127
Salary: $29600.04
Employee Level: Unassigned

Payment Slip for Worker 128
Salary: $7788.53
Employee Level: Unassigned

Payment Slip for Worker 129
Salary: $28273.85
Employee Level: Unassigned

Payment Slip for Worker 130
Salary: $23409.93
Employee Level: A5-F

Payment Slip for Worker 131
Salary: $25890.93
Employee Level: A5-F

Payment Slip for Worker 132
Salary: $8296.06
Employee Level: Unassigned

Payment Slip for Worker 133
Salary: $16553.04
Employee Level: A1

Payment Slip for Worker 134
Salary: $20870.66
Employee Level: Unassigned

Payment Slip for Worker 135
Salary: $22193.37
Employee Level: Unassigned

Payment Slip for Worker 136
Salary: $19741.69
Employee Level: A1

Payment Slip for Worker 137
Salary: $29583.99
Employee Level: A5-F

Payment Slip for Worker 138
Salary: $20591.88
Employee Level: Unassigned

Payment Slip for Worker 139
Salary: $22349.69
Employee Level: A5-F

Payment Slip for Worker 140
Salary: $17027.1
Employee Level: A1

Payment Slip for Worker 141
Salary: $8815.67
Employee Level: A5-F

Payment Slip for Worker 142
Salary: $24754.12
Employee Level: Unassigned

Payment Slip for Worker 143
Salary: $19897.93
Employee Level: A1

Payment Slip for Worker 144
Salary: $24008.42
Employee Level: Unassigned

Payment Slip for Worker 145
Salary: $22119.85
Employee Level: A5-F

Payment Slip for Worker 146
Salary: $26704.81
Employee Level: Unassigned

Payment Slip for Worker 147
Salary: $27631.65
Employee Level: Unassigned

Payment Slip for Worker 148
Salary: $9792.1
Employee Level: A5-F

Payment Slip for Worker 149
Salary: $16655.77
Employee Level: A1

Payment Slip for Worker 150
Salary: $18850.85
Employee Level: A1

Payment Slip for Worker 151
Salary: $7967.24
Employee Level: A5-F

Payment Slip for Worker 152
Salary: $23250.36
Employee Level: A5-F

Payment Slip for Worker 153
Salary: $23607.86
Employee Level: Unassigned

Payment Slip for Worker 154
Salary: $12787.09
Employee Level: A1

Payment Slip for Worker 155
Salary: $13388.43
Employee Level: A1

Payment Slip for Worker 156
Salary: $19689.46
Employee Level: A1

Payment Slip for Worker 157
Salary: $26255.69
Employee Level: Unassigned

Payment Slip for Worker 158
Salary: $28547.63
Employee Level: Unassigned

Payment Slip for Worker 159
Salary: $19064.89
Employee Level: A1

Payment Slip for Worker 160
Salary: $15566.97
Employee Level: A1

Payment Slip for Worker 161
Salary: $19340.1
Employee Level: A1

Payment Slip for Worker 162
Salary: $15287.54
Employee Level: A1

Payment Slip for Worker 163
Salary: $21277.1
Employee Level: A5-F

Payment Slip for Worker 164
Salary: $29521.67
Employee Level: Unassigned

Payment Slip for Worker 165
Salary: $25258.27
Employee Level: Unassigned

Payment Slip for Worker 166
Salary: $16298.84
Employee Level: A1

Payment Slip for Worker 167
Salary: $15492.75
Employee Level: A1

Payment Slip for Worker 168
Salary: $14851.08
Employee Level: A1

Payment Slip for Worker 169
Salary: $10839.44
Employee Level: A1

Payment Slip for Worker 170
Salary: $16194.07
Employee Level: A1

Payment Slip for Worker 171
Salary: $20899.61
Employee Level: Unassigned

Payment Slip for Worker 172
Salary: $12440.15
Employee Level: A1

Payment Slip for Worker 173
Salary: $14650.26
Employee Level: A1

Payment Slip for Worker 174
Salary: $16778.83
Employee Level: A1

Payment Slip for Worker 175
Salary: $14026.33
Employee Level: A1

Payment Slip for Worker 176
Salary: $12612.31
Employee Level: A1

Payment Slip for Worker 177
Salary: $29994.23
Employee Level: A5-F

Payment Slip for Worker 178
Salary: $20274.56
Employee Level: A5-F

Payment Slip for Worker 179
Salary: $25204.7
Employee Level: A5-F

Payment Slip for Worker 180
Salary: $11989.9
Employee Level: A1

Payment Slip for Worker 181
Salary: $13783.41
Employee Level: A1

Payment Slip for Worker 182
Salary: $22583.03
Employee Level: Unassigned

Payment Slip for Worker 183
Salary: $15720.31
Employee Level: A1

Payment Slip for Worker 184
Salary: $25466.32
Employee Level: A5-F

Payment Slip for Worker 185
Salary: $19243.62
Employee Level: A1

Payment Slip for Worker 186
Salary: $16411.69
Employee Level: A1

Payment Slip for Worker 187
Salary: $18559.54
Employee Level: A1

Payment Slip for Worker 188
Salary: $19032.95
Employee Level: A1

Payment Slip for Worker 189
Salary: $14384.65
Employee Level: A1

Payment Slip for Worker 190
Salary: $13511.77
Employee Level: A1

Payment Slip for Worker 191
Salary: $24658.41
Employee Level: Unassigned

Payment Slip for Worker 192
Salary: $21528.45
Employee Level: A5-F

Payment Slip for Worker 193
Salary: $8107.94
Employee Level: Unassigned

Payment Slip for Worker 194
Salary: $18017.46
Employee Level: A1

Payment Slip for Worker 195
Salary: $27271.72
Employee Level: Unassigned

Payment Slip for Worker 196
Salary: $21117.79
Employee Level: A5-F

Payment Slip for Worker 197
Salary: $21390.6
Employee Level: Unassigned

Payment Slip for Worker 198
Salary: $10943.55
Employee Level: A1

Payment Slip for Worker 199
Salary: $25492.3
Employee Level: A5-F

Payment Slip for Worker 200
Salary: $29826.78
Employee Level: Unassigned

Payment Slip for Worker 201
Salary: $11528.27
Employee Level: A1

Payment Slip for Worker 202
Salary: $29675.53
Employee Level: A5-F

Payment Slip for Worker 203
Salary: $21307.01
Employee Level: A5-F

Payment Slip for Worker 204
Salary: $29546.25
Employee Level: Unassigned

Payment Slip for Worker 205
Salary: $27308.47
Employee Level: Unassigned

Payment Slip for Worker 206
Salary: $27905.0
Employee Level: A5-F

Payment Slip for Worker 207
Salary: $19320.56
Employee Level: A1

Payment Slip for Worker 208
Salary: $17467.29
Employee Level: A1

Payment Slip for Worker 209
Salary: $21886.45
Employee Level: A5-F

Payment Slip for Worker 210
Salary: $18116.41
Employee Level: A1

Payment Slip for Worker 211
Salary: $27953.61
Employee Level: A5-F

Payment Slip for Worker 212
Salary: $14862.68
Employee Level: A1

Payment Slip for Worker 213
Salary: $29289.85
Employee Level: A5-F

Payment Slip for Worker 214
Salary: $9433.49
Employee Level: A5-F

Payment Slip for Worker 215
Salary: $22585.55
Employee Level: A5-F

Payment Slip for Worker 216
Salary: $19889.54
Employee Level: A1

Payment Slip for Worker 217
Salary: $16444.06
Employee Level: A1

Payment Slip for Worker 218
Salary: $13359.24
Employee Level: A1

Payment Slip for Worker 219
Salary: $13549.66
Employee Level: A1

Payment Slip for Worker 220
Salary: $26473.77
Employee Level: Unassigned

Payment Slip for Worker 221
Salary: $11142.08
Employee Level: A1

Payment Slip for Worker 222
Salary: $9497.01
Employee Level: A5-F

Payment Slip for Worker 223
Salary: $21192.48
Employee Level: A5-F

Payment Slip for Worker 224
Salary: $12016.3
Employee Level: A1

Payment Slip for Worker 225
Salary: $18537.49
Employee Level: A1

Payment Slip for Worker 226
Salary: $14948.94
Employee Level: A1

Payment Slip for Worker 227
Salary: $18857.91
Employee Level: A1

Payment Slip for Worker 228
Salary: $28476.9
Employee Level: Unassigned

Payment Slip for Worker 229
Salary: $12970.32
Employee Level: A1

Payment Slip for Worker 230
Salary: $26072.05
Employee Level: Unassigned

Payment Slip for Worker 231
Salary: $21731.35
Employee Level: Unassigned

Payment Slip for Worker 232
Salary: $14855.01
Employee Level: A1

Payment Slip for Worker 233
Salary: $13488.14
Employee Level: A1

Payment Slip for Worker 234
Salary: $9810.37
Employee Level: Unassigned

Payment Slip for Worker 235
Salary: $24327.13
Employee Level: A5-F

Payment Slip for Worker 236
Salary: $15867.74
Employee Level: A1

Payment Slip for Worker 237
Salary: $8000.15
Employee Level: Unassigned

Payment Slip for Worker 238
Salary: $13291.57
Employee Level: A1

Payment Slip for Worker 239
Salary: $26054.67
Employee Level: A5-F

Payment Slip for Worker 240
Salary: $20503.82
Employee Level: Unassigned

Payment Slip for Worker 241
Salary: $10970.48
Employee Level: A1

Payment Slip for Worker 242
Salary: $17982.05
Employee Level: A1

Payment Slip for Worker 243
Salary: $16114.16
Employee Level: A1

Payment Slip for Worker 244
Salary: $17948.47
Employee Level: A1

Payment Slip for Worker 245
Salary: $22531.45
Employee Level: Unassigned

Payment Slip for Worker 246
Salary: $21514.78
Employee Level: A5-F

Payment Slip for Worker 247
Salary: $27651.2
Employee Level: Unassigned

Payment Slip for Worker 248
Salary: $9671.11
Employee Level: Unassigned

Payment Slip for Worker 249
Salary: $26087.7
Employee Level: Unassigned

Payment Slip for Worker 250
Salary: $8622.68
Employee Level: A5-F

Payment Slip for Worker 251
Salary: $19736.32
Employee Level: A1

Payment Slip for Worker 252
Salary: $19579.08
Employee Level: A1

Payment Slip for Worker 253
Salary: $20326.68
Employee Level: A5-F

Payment Slip for Worker 254
Salary: $21499.59
Employee Level: A5-F

Payment Slip for Worker 255
Salary: $25645.71
Employee Level: Unassigned

Payment Slip for Worker 256
Salary: $22170.79
Employee Level: A5-F

Payment Slip for Worker 257
Salary: $17153.07
Employee Level: A1

Payment Slip for Worker 258
Salary: $28581.81
Employee Level: A5-F

Payment Slip for Worker 259
Salary: $16897.86
Employee Level: A1

Payment Slip for Worker 260
Salary: $18104.47
Employee Level: A1

Payment Slip for Worker 261
Salary: $24671.29
Employee Level: A5-F

Payment Slip for Worker 262
Salary: $28183.66
Employee Level: A5-F

Payment Slip for Worker 263
Salary: $16212.47
Employee Level: A1

Payment Slip for Worker 264
Salary: $20440.85
Employee Level: A5-F

Payment Slip for Worker 265
Salary: $23024.74
Employee Level: A5-F

Payment Slip for Worker 266
Salary: $13734.88
Employee Level: A1

Payment Slip for Worker 267
Salary: $14808.22
Employee Level: A1

Payment Slip for Worker 268
Salary: $17587.22
Employee Level: A1

Payment Slip for Worker 269
Salary: $11362.27
Employee Level: A1

Payment Slip for Worker 270
Salary: $20862.81
Employee Level: A5-F

Payment Slip for Worker 271
Salary: $16486.86
Employee Level: A1

Payment Slip for Worker 272
Salary: $11109.32
Employee Level: A1

Payment Slip for Worker 273
Salary: $13063.12
Employee Level: A1

Payment Slip for Worker 274
Salary: $20452.68
Employee Level: A5-F

Payment Slip for Worker 275
Salary: $27748.52
Employee Level: A5-F

Payment Slip for Worker 276
Salary: $18713.97
Employee Level: A1

Payment Slip for Worker 277
Salary: $23310.35
Employee Level: A5-F

Payment Slip for Worker 278
Salary: $23449.16
Employee Level: Unassigned

Payment Slip for Worker 279
Salary: $17833.97
Employee Level: A1

Payment Slip for Worker 280
Salary: $20019.78
Employee Level: Unassigned

Payment Slip for Worker 281
Salary: $14996.0
Employee Level: A1

Payment Slip for Worker 282
Salary: $11459.89
Employee Level: A1

Payment Slip for Worker 283
Salary: $13183.42
Employee Level: A1

Payment Slip for Worker 284
Salary: $21214.0
Employee Level: A5-F

Payment Slip for Worker 285
Salary: $28491.45
Employee Level: A5-F

Payment Slip for Worker 286
Salary: $25833.2
Employee Level: A5-F

Payment Slip for Worker 287
Salary: $10841.73
Employee Level: A1

Payment Slip for Worker 288
Salary: $24103.98
Employee Level: A5-F

Payment Slip for Worker 289
Salary: $20956.2
Employee Level: Unassigned

Payment Slip for Worker 290
Salary: $10794.29
Employee Level: A1

Payment Slip for Worker 291
Salary: $24619.49
Employee Level: A5-F

Payment Slip for Worker 292
Salary: $15432.88
Employee Level: A1

Payment Slip for Worker 293
Salary: $29993.72
Employee Level: Unassigned

Payment Slip for Worker 294
Salary: $10964.45
Employee Level: A1

Payment Slip for Worker 295
Salary: $7675.82
Employee Level: A5-F

Payment Slip for Worker 296
Salary: $20591.48
Employee Level: Unassigned

Payment Slip for Worker 297
Salary: $11031.74
Employee Level: A1

Payment Slip for Worker 298
Salary: $22555.08
Employee Level: Unassigned

Payment Slip for Worker 299
Salary: $23175.77
Employee Level: A5-F

Payment Slip for Worker 300
Salary: $27673.06
Employee Level: Unassigned

Payment Slip for Worker 301
Salary: $26700.6
Employee Level: A5-F

Payment Slip for Worker 302
Salary: $18729.35
Employee Level: A1

Payment Slip for Worker 303
Salary: $11645.41
Employee Level: A1

Payment Slip for Worker 304
Salary: $18342.96
Employee Level: A1

Payment Slip for Worker 305
Salary: $24345.82
Employee Level: Unassigned

Payment Slip for Worker 306
Salary: $27868.97
Employee Level: A5-F

Payment Slip for Worker 307
Salary: $16565.91
Employee Level: A1

Payment Slip for Worker 308
Salary: $22959.91
Employee Level: A5-F

Payment Slip for Worker 309
Salary: $16759.88
Employee Level: A1

Payment Slip for Worker 310
Salary: $21280.07
Employee Level: Unassigned

Payment Slip for Worker 311
Salary: $22917.2
Employee Level: A5-F

Payment Slip for Worker 312
Salary: $27400.45
Employee Level: A5-F

Payment Slip for Worker 313
Salary: $28157.79
Employee Level: A5-F

Payment Slip for Worker 314
Salary: $18617.51
Employee Level: A1

Payment Slip for Worker 315
Salary: $13733.28
Employee Level: A1

Payment Slip for Worker 316
Salary: $29984.63
Employee Level: Unassigned

Payment Slip for Worker 317
Salary: $8121.38
Employee Level: A5-F

Payment Slip for Worker 318
Salary: $8451.81
Employee Level: A5-F

Payment Slip for Worker 319
Salary: $13622.37
Employee Level: A1

Payment Slip for Worker 320
Salary: $20748.34
Employee Level: Unassigned

Payment Slip for Worker 321
Salary: $11301.28
Employee Level: A1

Payment Slip for Worker 322
Salary: $20699.4
Employee Level: Unassigned

Payment Slip for Worker 323
Salary: $28866.21
Employee Level: Unassigned

Payment Slip for Worker 324
Salary: $20676.63
Employee Level: A5-F

Payment Slip for Worker 325
Salary: $7945.39
Employee Level: Unassigned

Payment Slip for Worker 326
Salary: $16539.27
Employee Level: A1

Payment Slip for Worker 327
Salary: $26726.25
Employee Level: Unassigned

Payment Slip for Worker 328
Salary: $26299.84
Employee Level: Unassigned

Payment Slip for Worker 329
Salary: $27560.14
Employee Level: Unassigned

Payment Slip for Worker 330
Salary: $10464.3
Employee Level: A1

Payment Slip for Worker 331
Salary: $28115.93
Employee Level: A5-F

Payment Slip for Worker 332
Salary: $16319.89
Employee Level: A1

Payment Slip for Worker 333
Salary: $19622.4
Employee Level: A1

Payment Slip for Worker 334
Salary: $25012.02
Employee Level: A5-F

Payment Slip for Worker 335
Salary: $20836.88
Employee Level: Unassigned

Payment Slip for Worker 336
Salary: $11049.31
Employee Level: A1

Payment Slip for Worker 337
Salary: $24375.69
Employee Level: Unassigned

Payment Slip for Worker 338
Salary: $20102.21
Employee Level: A5-F

Payment Slip for Worker 339
Salary: $11454.99
Employee Level: A1

Payment Slip for Worker 340
Salary: $23366.85
Employee Level: A5-F

Payment Slip for Worker 341
Salary: $15429.7
Employee Level: A1

Payment Slip for Worker 342
Salary: $7925.61
Employee Level: A5-F

Payment Slip for Worker 343
Salary: $14808.28
Employee Level: A1

Payment Slip for Worker 344
Salary: $25810.73
Employee Level: Unassigned

Payment Slip for Worker 345
Salary: $19453.5
Employee Level: A1

Payment Slip for Worker 346
Salary: $16108.58
Employee Level: A1

Payment Slip for Worker 347
Salary: $23589.99
Employee Level: Unassigned

Payment Slip for Worker 348
Salary: $19510.68
Employee Level: A1

Payment Slip for Worker 349
Salary: $15373.82
Employee Level: A1

Payment Slip for Worker 350
Salary: $26391.09
Employee Level: Unassigned

Payment Slip for Worker 351
Salary: $11097.75
Employee Level: A1

Payment Slip for Worker 352
Salary: $9703.34
Employee Level: Unassigned

Payment Slip for Worker 353
Salary: $9895.52
Employee Level: A5-F

Payment Slip for Worker 354
Salary: $29610.22
Employee Level: A5-F

Payment Slip for Worker 355
Salary: $29265.93
Employee Level: Unassigned

Payment Slip for Worker 356
Salary: $8380.86
Employee Level: A5-F

Payment Slip for Worker 357
Salary: $10609.61
Employee Level: A1

Payment Slip for Worker 358
Salary: $28147.93
Employee Level: A5-F

Payment Slip for Worker 359
Salary: $14869.62
Employee Level: A1

Payment Slip for Worker 360
Salary: $12370.37
Employee Level: A1

Payment Slip for Worker 361
Salary: $12442.61
Employee Level: A1

Payment Slip for Worker 362
Salary: $11897.56
Employee Level: A1

Payment Slip for Worker 363
Salary: $13637.52
Employee Level: A1

Payment Slip for Worker 364
Salary: $22009.48
Employee Level: A5-F

Payment Slip for Worker 365
Salary: $11603.86
Employee Level: A1

Payment Slip for Worker 366
Salary: $14077.19
Employee Level: A1

Payment Slip for Worker 367
Salary: $11233.46
Employee Level: A1

Payment Slip for Worker 368
Salary: $26065.38
Employee Level: A5-F

Payment Slip for Worker 369
Salary: $8747.68
Employee Level: A5-F

Payment Slip for Worker 370
Salary: $21575.57
Employee Level: A5-F

Payment Slip for Worker 371
Salary: $16961.31
Employee Level: A1

Payment Slip for Worker 372
Salary: $23762.45
Employee Level: A5-F

Payment Slip for Worker 373
Salary: $14116.74
Employee Level: A1

Payment Slip for Worker 374
Salary: $28139.34
Employee Level: A5-F

Payment Slip for Worker 375
Salary: $14554.48
Employee Level: A1

Payment Slip for Worker 376
Salary: $19161.93
Employee Level: A1

Payment Slip for Worker 377
Salary: $7783.45
Employee Level: A5-F

Payment Slip for Worker 378
Salary: $14858.81
Employee Level: A1

Payment Slip for Worker 379
Salary: $22249.17
Employee Level: A5-F

Payment Slip for Worker 380
Salary: $25342.57
Employee Level: A5-F

Payment Slip for Worker 381
Salary: $8564.46
Employee Level: A5-F

Payment Slip for Worker 382
Salary: $15223.13
Employee Level: A1

Payment Slip for Worker 383
Salary: $28145.3
Employee Level: Unassigned

Payment Slip for Worker 384
Salary: $11691.0
Employee Level: A1

Payment Slip for Worker 385
Salary: $11027.08
Employee Level: A1

Payment Slip for Worker 386
Salary: $9103.59
Employee Level: Unassigned

Payment Slip for Worker 387
Salary: $17470.85
Employee Level: A1

Payment Slip for Worker 388
Salary: $22209.4
Employee Level: Unassigned

Payment Slip for Worker 389
Salary: $18335.44
Employee Level: A1

Payment Slip for Worker 390
Salary: $17962.83
Employee Level: A1

Payment Slip for Worker 391
Salary: $18612.29
Employee Level: A1

Payment Slip for Worker 392
Salary: $12034.01
Employee Level: A1

Payment Slip for Worker 393
Salary: $10066.3
Employee Level: A1

Payment Slip for Worker 394
Salary: $22997.9
Employee Level: Unassigned

Payment Slip for Worker 395
Salary: $9185.47
Employee Level: A5-F

Payment Slip for Worker 396
Salary: $9744.67
Employee Level: A5-F

Payment Slip for Worker 397
Salary: $22347.85
Employee Level: Unassigned

Payment Slip for Worker 398
Salary: $20308.67
Employee Level: A5-F

Payment Slip for Worker 399
Salary: $12373.04
Employee Level: A1

Payment Slip for Worker 400
Salary: $11479.46
Employee Level: A1

